package bict.com;

import javax.swing.*;
public class Student {
    private JButton LOGOUTButton;
    private JLabel UserProfile;
    private JLabel Course;
    private JLabel Exam;
    private JLabel Menu;
    private JPanel first;
    private JPanel second;
    private JLabel logo;
    private JLabel UniName;
    private JLabel FOT;
    private JLabel TECMIS;
    private JPanel third;


    }

